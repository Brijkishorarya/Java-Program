package brijkishor;

public class Krish {
	public static void main(String[] args) {
		System.out.println("God tu hi h");
	}
}
