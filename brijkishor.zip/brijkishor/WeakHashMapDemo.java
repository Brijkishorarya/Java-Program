/*package brijkishor;

import java.util.WeakHashMap;

public class WeakHashMapDemo {
	public static void main(String[] args) throws Exception {
		WeakHashMap weakHashMap = new WeakHashMap<>(); 
		
		weakHashMap.put(t, "Brijkishor"); 
		System.out.println(weakHashMap);
		t= null; 
		System.gc();
		Thread.sleep(5000);
		System.out.println(weakHashMap);
	}
}

class Temp 
{
	public String toString()
	{
		return "Temp"; 
	}
	public void finalize() {
		System.out.println("finalize() method called");
	}
}*/
