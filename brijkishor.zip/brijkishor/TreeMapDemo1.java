package brijkishor;

import java.util.Comparator;
import java.util.TreeMap;

public class TreeMapDemo1 {
	public static void main(String[] args) {
		TreeMap treeMap = (new TreeMap());
	/*	treeMap.put("XXX", 10); 
		treeMap.put("AAA", 20); 
		treeMap.put("ZZZ", 30); 
		treeMap.put("LLL", 40); */
		System.out.println(treeMap);
	}
}
class MyComparator implements Comparator
{
	public int compare(Object obj1, Object obj2) {
		String string = obj1.toString(); 
		String string2 = obj2.toString(); 
		return string2.compareTo(string);
	}
}
