package brijkishor;

class MyThread7 extends Thread
{
	
}

public class ThreadPriorityDemo {
	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(9);
		MyThread thread = new MyThread(); 
		System.out.println(thread.getPriority());
	}
}