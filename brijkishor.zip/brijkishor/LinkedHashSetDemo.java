package brijkishor;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {
	public static void main(String[] args) {
		LinkedHashSet linkedHashSet = new LinkedHashSet(); 
		/*linkedHashSet.add('B');
		linkedHashSet.add('C');
		linkedHashSet.add('D');
		linkedHashSet.add('E');
		linkedHashSet.add('Y');
		linkedHashSet.add(null); 
		linkedHashSet.add(10); */
		//System.out.println(linkedHashSet.add('y'));
		System.out.println(linkedHashSet);
	}
}
