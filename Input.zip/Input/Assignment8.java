package Input;
import java.util.Scanner;

public class Assignment8 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        //System.out.println("Enter your first string value: ");
        String first = s.next(); 
       //System.out.println("Enter your second string value: ");
        String second = s.next(); 
        System.out.println(first +second);
    }
}
