/*Write a Java program to check if a number is a palindrome in Java? ( 121 is a
palindrome, 321 is not)*/

package brijkishor;

public class Assign16 {

	
	static void numberisPalindrome(int n)
	{
		int temp = 0;
		int m = 0;
		int r = 0;
		
		temp	=	n;
		while (n>0) {
			m = n % 10;
			r = r * 10 + m;
			n = n / 10;
		}
		
		if (temp==r) {
			System.out.println(true);
		} else {
			System.out.println(false);
		}
	}
	public static void main(String[] args) {
		numberisPalindrome(132223);
	}
}
