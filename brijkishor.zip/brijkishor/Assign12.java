package brijkishor;

public class Assign12 {
	
	static void swap(int a, int b)
	{
		int temp = 0;
		temp	=	a;//5
		a = b; //6
		b	=	temp;
		System.out.println("After swap value of a is:"+a);
		System.out.println("After swap value of b is:"+b);
	}
	
	static	void	swapwithoutthirdvariable(int a, int b)
	{
		a = a + b; //11
		b = a - b;//5
		a = a - b;//6
		System.out.println("After swap value of a is:"+a);
		System.out.println("After swap value of b is:"+b);
	}
	public static void main(String[] args) {
		int a = 5;
		int b = 6;
		System.out.println("Before swap value of a is:"+a);
		System.out.println("Before swap value of b is:"+b);
		swap(a, b);
		swapwithoutthirdvariable(a, b);
	}
	
}
