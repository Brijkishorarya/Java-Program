//Write a Java method to compute the sum of the digits in an integer

package brijkishor;

public class Finddigit {
	
	static	void	findDigitsnumber(int	n)
	{
		int	d	=	0;
		int	sum	=	0;
		
		while (n>0) {
			d	=	n	%	10;
			sum	=	sum	+	d;
			n	=	n	/	10;	
		}
		
		System.out.println(sum);
	}
	public static void main(String[] args) {
		findDigitsnumber(4567);
	}
}
