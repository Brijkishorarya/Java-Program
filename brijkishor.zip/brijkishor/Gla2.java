package brijkishor;

public class Gla2 {
	//int x = 5; 
	public static void main(String[] args) {
		int x; 
		x = 5; 
		{
			int y = 6; 
			System.out.println(x+""+y);
		}
		System.out.println(x+"");
		
	}
}
