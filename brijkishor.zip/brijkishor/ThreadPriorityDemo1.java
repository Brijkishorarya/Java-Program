package brijkishor;

class MyThread8 extends Thread
{
	public void run()
	{
		for(int i = 0; i<10; i++)
		{
			System.out.println("Child thread");
		}
	}
}

public class ThreadPriorityDemo1 {
	public static void main(String[] args) {
		MyThread8 thread8 = new MyThread8(); 
		thread8.setPriority(10);
		thread8.start();
		for (int i = 0; i < 10; i++) {
			System.out.println("main thread");
		}
	}
}
