package Input;
import java.util.Scanner; 
public class Assignment12 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in); 
        String a = s.next(); 
        String b = s.next(); 
        String c = s.next(); 
        String d = s.next();
        String i = s.next(); 
        String j = s.next();
        String x = s.next(); 
        String y = s.next();
        System.out.println(a+b);
        System.out.println(c+d);
        System.out.println(i+j);
        System.out.println(x+y);
        /*String b = s.nextLine(); 
        String c = s.nextLine(); 
        String d = s.nextLine(); 
        System.out.println(a); 
        System.out.println(b); 
        System.out.println(c); 
        System.out.println(d); */

    }
}
