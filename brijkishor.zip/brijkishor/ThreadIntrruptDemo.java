/*package brijkishor;

class MyThreaded extends Thread
{
	public void run()
	{
		try {
			for(int i=0; i<5; i++)
			{
				System.out.println("i am lazy thread: "+i);
				//Thread.sleep(2000);
				
			}
		} catch (InterruptedException e) {
			// TODO: handle exception
			System.out.println("i got interrupted");
		}
}
	

public class ThreadIntrruptDemo {
	public static void main(String[] args) {
		MyThreaded threaded = new MyThreaded(); 
		threaded.start();
		threaded.interrupt();
		System.out.println("End of main thread");
	}
}

*/