/*Write a method named isEven that accepts an int argument. The method
should return true if the argument is even, or false otherwise. Also write a program to test your
method.*/

package brijkishor;

import java.util.Scanner;

public class Assign15 {
	
	static void isEven(int n)
	{
		if (n%2==0) {
			System.out.println(true);
		}
		else {
			System.out.println(false);
		}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a positive integer value:");
		int n = scanner.nextInt();
		isEven(n);
		//isEven(10);
	}
}
