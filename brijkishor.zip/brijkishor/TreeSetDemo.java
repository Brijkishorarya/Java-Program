package brijkishor;

import java.util.TreeSet;

public class TreeSetDemo {
	public static void main(String[] args) {
		TreeSet treeSet = new TreeSet(); 
	/*	treeSet.add('A'); 
		treeSet.add('B'); 
		treeSet.add('a'); 
		treeSet.add('Z'); 
		treeSet.add('L'); */
	/*	treeSet.add(11); 
		treeSet.add(12); 
		treeSet.add(13); 
		treeSet.add(14); 
		treeSet.add(15); */
		//treeSet.add(new Integer(10)); 
		System.out.println(treeSet);
		System.out.println(new Integer(12));
		//System.out.println(new String('A'));
		//System.out.println(new String('A'));
		treeSet.add(null); 
		treeSet.add(null); 
		System.out.println(treeSet);
	}
}
