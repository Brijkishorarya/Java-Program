/*Q4. Calculate the minimum element in the array {2, -3, 5, 8, 1, 0, -4} using standard library method 
for calculating the minimum element.
Output:
-4*/

package brijkishor;

import java.util.Iterator;

public class Assign4 {
	public static void main(String[] args) {
		int	arr[]	=	{2,-3,5,8,1,0,-4};
		for (int i = 1; i < arr.length-1; i++) {
			if (arr[i-1]<arr[i]&&arr[i]>arr[i+1]) {
				System.out.println(arr[i]);
			}
			
		}
	}
}
