/*Q2 - Given two arrays a[] and b[] of size n and m respectively where m >= n. The task is to find 
 union between these two arrays and print the number of elements of the union set.
 Union of the two arrays can be defined as the set containing distinct elements from both 
 the arrays. If there are repetitions, then only one occurrence of element should be printed 
 in the union.

Input1:

Output1:

5 3

1 2 3 4 5

1 2 3

5*/
 

package brijkishor;

//import java.util.Iterator;
import java.util.Scanner;

public class Assign7 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int	n	=	scanner.nextInt();
		int	m	=	scanner.nextInt();
		int	a[]	=	new	int[n];
		int	b[]	=	new	int[n];
		for (int i = 0; i < n; i++) {
			a[i]	=	scanner.nextInt();
		}
		for (int i = 0; i < m; i++) {
			b[i]	=	scanner.nextInt();
			boolean	check	=	false;
			for (int j = 0; j < n; j++) {
				if(b[i]	==	a[j])
				{
					check	=	true;
					break;
				}
				
			}
			if (!check) {
				System.out.println(b[i]);
				
			}
		}
		
	}
}
