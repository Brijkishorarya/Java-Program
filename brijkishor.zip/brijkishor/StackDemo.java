package brijkishor;

import java.util.Stack;

public class StackDemo {
	public static void main(String[] args) {
		Stack stack = new Stack(); 
		stack.push("A"); 
	/*	stack.push('B'); 
		stack.push('c'); 
		stack.push('D'); 
		stack.push('E'); */
		System.out.println(stack);
		stack.pop();
		System.out.println(stack); 
		//stack.peek(); 
		System.out.println(stack.peek());
		stack.add("F"); 
		System.out.println(stack);
		stack.pop(); 
		System.out.println(stack);
		//stack.search("B"); 
		//System.out.println(stack.search('D'));
		//System.out.println(stack.search('M'));
		System.out.println(stack.empty());
		
	}
}
