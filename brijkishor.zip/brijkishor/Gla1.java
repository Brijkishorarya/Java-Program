package brijkishor;

import java.io.File;
import java.io.IOException;

public class Gla1 {
	public static void main(String[] args) throws IOException{
		File file = new File("bhaskar123"); 
		file.mkdir(); 
		File file2 = new File("bhaskar123", "abc.txt"); 
		file2.createNewFile(); 
		
		/*File file = new File("demo.xlsx"); 
		file.createNewFile(); 
		System.out.println("sucess");*/
		
		/*File file = new File("cricket.pdf");
		System.out.println(file.exists());
		file.createNewFile(); 
		System.out.println(file.exists());*/
		
	/*	File file = new File("brij.txt"); 
		System.out.println(file.exists());
		file.createNewFile(); 
		System.out.println(file.exists());*/
	}
}
