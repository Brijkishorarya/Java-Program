package brijkishor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;


public class FileWriterDemo1 {
	public static void main(String[] args) throws IOException{
		PrintWriter printWriter = new PrintWriter("file3.txt"); 
		BufferedReader bufferedReader = new BufferedReader(new FileReader("file1.txt"));
		String line = bufferedReader.readLine(); 
		while (line!=null) {
			printWriter.println(line);
			line = bufferedReader.readLine(); 
		}
		bufferedReader = new BufferedReader(new FileReader("file2.txt")); 
		line = bufferedReader.readLine(); 
		while (line!=null) {
			printWriter.println(line);
		}
		printWriter.flush();
		bufferedReader.close();
		printWriter.close();
	}
}
