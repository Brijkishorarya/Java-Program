package brijkishor;


public class Ram1 {

	public static void main(String[] args) {
	int var = 43; 
	int var2 = ~var; 
	System.out.println(var + " "+ var2);
	}
	
}
