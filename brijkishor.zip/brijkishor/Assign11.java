package brijkishor;

import java.util.Scanner;

public class Assign11 {
	public static void main(String[] args) {
		int	count	=	0;
		Scanner	scanner	=	new	Scanner(System.in);
		System.out.println("Enter length of array:");
		int n = scanner.nextInt();
		int	arr[]	=	new int[n];
		for (int i = 0; i < n; i++) {
			arr[i] = scanner.nextInt();
		}
		
		int	x	=	scanner.nextInt();
		for (int i = 0; i < n;  i++) {
			//for (int j = i+1; j < n; j++) {
				if(arr[i]==x)
				{
					count++;
				}
				//System.out.println(count);
			}
			System.out.println(count);
			
		}
	}

