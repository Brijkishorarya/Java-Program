package brijkishor;

import java.io.FileOutputStream;

public class File {
	public static void main(String[] args) {
		try {
			FileOutputStream f = new FileOutputStream("C:\\Study\\brij.txt"); 
			f.write(65);
			f.close(); 
			System.out.println("success...");
 		} catch (Exception e) {
			// TODO: handle exception
 			System.out.println(e);
		}
	}
}
