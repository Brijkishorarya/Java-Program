package brijkishor;

import java.util.HashMap;

public class HashMapDemo1 {
	public static void main(String[] args) {
		HashMap hashMap = new HashMap(); 
		Integer integer = new Integer(10); 
		Integer integer2 = new Integer(10); 
		hashMap.put(integer, "Brij"); 
		hashMap.put(integer2, "arya"); 
		//System.out.println(hashMap.get(10));
		//10 == integer.....false; 
		//10 == integer2......false; 
	//	System.out.println(hashMap);
	}
}
