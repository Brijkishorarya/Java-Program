package brijkishor;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Filestring {
	public static void main(String[] args) {
		try {
			FileOutputStream fileOutputStream = new FileOutputStream("c:\\study\\brij.txt");
			String string = "Hi Brijkishor arya welcome to GLA University Mathura Uttar Pradesh.";
			byte b[]=string.getBytes(); 
			fileOutputStream.write(b);
			fileOutputStream.close();
			System.out.println("Success....");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
