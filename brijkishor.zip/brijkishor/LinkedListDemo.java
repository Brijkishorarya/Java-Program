package brijkishor;

import java.util.LinkedList;

public class LinkedListDemo {
	public static void main(String[] args) {
		LinkedList linkedList = new LinkedList();  
		linkedList.add("bhaskar"); 
		//linkedList.add(30); 
		linkedList.add(null); 
		linkedList.add("brijkishor"); 
		System.out.println(linkedList);
		linkedList.addFirst("guddu");
		System.out.println(linkedList);
		linkedList.addLast("sisodiya ji");
		System.out.println(linkedList);
		//linkedList.getFirst();
		System.out.println(linkedList.getFirst());
		//linkedList.getLast(); 
		System.out.println(linkedList.getLast());
		linkedList.removeFirst(); 
		System.out.println(linkedList);
		linkedList.removeLast(); 
		System.out.println(linkedList);
		/*linkedList.set(0, "Software"); 
		System.out.println(linkedList);
		linkedList.set(0, "venky"); 
		System.out.println(linkedList);
		linkedList.removeLast();
		System.out.println(linkedList);
		linkedList.removeFirst(); 
		System.out.println(linkedList);
		linkedList.addFirst("vvv");
		System.out.println(linkedList);*/
		
	}
}
