package brijkishor;

public class PracticeMath {
	public static void main(String[] args) {
		double	x	=	4;
		double	y	=	16;
		
		//a. Math.min()
		System.out.println("Minimum value of x and y "+Math.min(x, y));
		
		//b. Math.max()
		System.out.println("Maximum value of x and y "+Math.max(x, y));
		
		//c. Math.sqrt()
		System.out.println("Square root of x "+Math.sqrt(y));
		
		//d. Math.pow()
		System.out.println("Power of value is "+Math.pow(x, y));
		
		//e. Math.avg()
		//System.out.println("Average of value is: ");
		
		//f. Math.abs()
		System.out.println(+Math.abs(y));
	}
}
