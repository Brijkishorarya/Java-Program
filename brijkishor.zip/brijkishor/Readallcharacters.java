package brijkishor;

import java.io.FileInputStream;

public class Readallcharacters {
	public static void main(String[] args) {
		try {
			FileInputStream fileInputStream = new FileInputStream("c:\\study\\brij.txt"); 
			int i = 0; 
			while ((i=fileInputStream.read())!=-1) {
				System.out.print((char)i);
			}
			fileInputStream.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
