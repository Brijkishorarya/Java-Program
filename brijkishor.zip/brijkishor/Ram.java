package brijkishor;



public class Ram {
	public static void main(String[] args) {
		for(int i = 2; i<=10; i+=2)
		{
			for(int j = 0; j<=6; i++)
			{
				if(i<8)
					break; 
				System.out.println("i = " + i + " j= " +j);
			}
		}
	}
}
