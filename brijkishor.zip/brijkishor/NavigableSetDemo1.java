package brijkishor;

import java.util.TreeSet;

public class NavigableSetDemo1 {
	public static void main(String[] args) {
	/*	TreeSet<Integer> treeSet = new TreeSet<Integer>(); 
		treeSet.add(1000); 
		treeSet.add(2000); 
		treeSet.add(3000); 
		treeSet.add(4000); 
		treeSet.add(5000); 
		System.out.println(treeSet);
		System.out.println(treeSet.ceiling(2000));
		System.out.println(treeSet.higher(2000));
		System.out.println(treeSet.floor(3000));
		System.out.println(treeSet.lower(3000)); 
		System.out.println(treeSet.pollFirst());
		System.out.println(treeSet.pollLast());
		System.out.println(treeSet.descendingSet());
		System.out.println(treeSet);*/
	}
}
