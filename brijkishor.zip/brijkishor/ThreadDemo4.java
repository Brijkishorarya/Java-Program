package brijkishor;

class MyThread5 extends Thread
{
	public void run()
	{
		System.out.println("no arg method");
	}
	
	public void run(int i)
	{
		System.out.println("int arg method");
	}
}

 class ThreadDemo4 {
	public static void main(String[] args) {
		MyThread thread = new MyThread(); 
		thread.start();
	}

}
