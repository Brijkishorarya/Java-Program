package brijkishor;

import java.util.Hashtable;
import java.util.*;

public class HashtableDemo {
	public static void main(String[] args) {
		Hashtable hashtable = new Hashtable(); 
		hashtable.put(new Temp(5), "A"); 
		hashtable.put(new Temp(2), "B"); 
		hashtable.put(new Temp(6), "C"); 
		hashtable.put(new Temp(15), "D"); 
		hashtable.put(new Temp(23), "E"); 
		hashtable.put(new Temp(16), "F"); 
		System.out.println(hashtable);
	}
}
class Temp
{
	int i; 
	Temp(int i)
	{
		this.i=i; 
	}
	public int hashCode()
	{
		return i; 
	}
	public String tostString()
	{
		return i+""; 
	}
}
