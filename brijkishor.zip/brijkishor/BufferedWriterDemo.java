package brijkishor;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterDemo {
	public static void main(String[] args) throws IOException {
		FileWriter fileWriter = new FileWriter("cricket.txt"); 
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter); 
		bufferedWriter.write(100);
		bufferedWriter.newLine();
		bufferedWriter.write(97);
		bufferedWriter.newLine();
		char[] ch = {'a', 'b', 'c', 'd'}; 
		bufferedWriter.write(ch);
		bufferedWriter.newLine();
		bufferedWriter.write("bhaskar");
		bufferedWriter.newLine();
		bufferedWriter.write("software solutions");
		bufferedWriter.flush();
		bufferedWriter.close();
	}
}
