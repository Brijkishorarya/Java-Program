package brijkishor;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterDemo {
	public static void main(String[] args) throws IOException{
		FileWriter fileWriter = new FileWriter("cricket.txt"); 
		PrintWriter printWriter = new PrintWriter(fileWriter); 
		printWriter.write(100);
		printWriter.println(100);
		printWriter.println(true);
		printWriter.println('c');
		printWriter.println("Guddu bhaiya the king of mirzapur:");
		printWriter.flush(); 
		printWriter.close();
	}
}
