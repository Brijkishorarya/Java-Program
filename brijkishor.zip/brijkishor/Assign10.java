/*Q1 - Given an array sorted in increasing order of size n and an integer x, find if there exists a 
 pair in the array whose absolute difference is exactly x.(n>1)
 Input1:
 N = 5
Arr[] = [5,10,15,20,26]
x= 10

Output1:
Yes

Input2:
N = 7
Arr[] = [1, 2, 3, 4, 5, 6, 7]
x= 0
Output2:
No
*/

package brijkishor;

import java.util.Scanner;

public class Assign10 {
	public static void main(String[] args) {
		Scanner	scanner	=	new	Scanner(System.in);
		System.out.println("Enter the length of the array:  ");
		int n = scanner.nextInt();
		int[] arr = new int[n];
		for (int i = 0; i < n; i++) {
			arr[i] = scanner.nextInt();
		}
		int x = scanner.nextInt();
		for (int i = 0; i < n; i++) {
			for (int j = i+1; j < n; j++) {
				if(arr[j]-arr[i]==x)
				{
					System.out.print("Yes");
					return;
				}
			}
		}
		System.out.print("No");
	}
}
