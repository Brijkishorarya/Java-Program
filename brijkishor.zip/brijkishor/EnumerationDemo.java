package brijkishor;

import java.util.Enumeration;
import java.util.Vector;

/*public class EnumerationDemo {
	public static void main(String[] args) {
		/*Vector vector = new Vector<>(); 
		for (int i = 0; i <= 10; i++) {
			vector.addElement(i);
		}
		System.out.println(vector);
		Enumeration enumeration = vector.elements(); 
		while (enumeration.hasMoreElements()) {
			Integer integer = (Integer)enumeration.nextElement(); 
			if(integer%2==0)
				System.out.println(integer);
		}
		System.out.println(vector);
	}
}*/
