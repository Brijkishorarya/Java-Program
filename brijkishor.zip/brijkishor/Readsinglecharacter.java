package brijkishor;

import java.io.FileInputStream;
import java.lang.module.FindException;

public class Readsinglecharacter {
	public static void main(String[] args) {
		try {
			FileInputStream fileInputStream = new FileInputStream("c:\\study\\brij.txt"); 
			int i = fileInputStream.read(); 
			System.out.println((char)i);
			fileInputStream.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
