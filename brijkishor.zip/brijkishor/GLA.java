package brijkishor;

import java.util.Scanner;

public class GLA {

	public static void main(String args[])
	{
		Scanner scanner =  new Scanner(System.in); 
	}
}
