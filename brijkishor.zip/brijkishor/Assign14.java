//Write a Java method to compute the average of three numbers.

package brijkishor;

public class Assign14 {
	
	static void avgNumber(int a, int b, int c)
	{
		float sum = 0;
		float avg = 0;
		sum = a+b+c;
		avg = sum/3;
		System.out.println("Average of three numbers is:"+avg);
	}
	public static void main(String[] args) {
		avgNumber(8, 5, 3);
	}
}
