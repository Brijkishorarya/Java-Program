package brijkishor;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterDemo {
	public static void main(String[] args) throws IOException{
		FileWriter fileWriter = new FileWriter("cricket.txt"); 
		fileWriter.write(98);
		fileWriter.write("haskar\nsoftware solution");
		fileWriter.write("\n"); 
		char [] ch = {'a', 'b', 'c'}; 
		fileWriter.write(ch);
		fileWriter.write("\n");
		fileWriter.flush();
		fileWriter.close();
		
	}
}
