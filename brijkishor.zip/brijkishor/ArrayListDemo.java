package brijkishor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList arrayList = new ArrayList(); 
		arrayList.add("pen");
		arrayList.add("brij");
		//arrayList.add(1023); 
		//arrayList.add(15.02); 
		System.out.println(arrayList);
		
	}
}
