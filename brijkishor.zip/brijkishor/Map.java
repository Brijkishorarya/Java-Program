package brijkishor;

import java.util.HashMap;

public class Map {
	public static void main(String[] args) {
		HashMap map = new HashMap(); 
		map.put("100", "Vijay");
		map.put("100", "Brijkishor arya"); 
		map.put("100", "Vijay");
		map.put("100", "Harshit"); 
		map.put("100", "Adarsh");
	//	map.put(100, "Garvit"); 
	//	map.put("Aman", 100);
		map.put("100", "Vikash"); 
		map.put("100", "Omendra");
		map.put("100", "Aditya"); 
	//	map.put("Collage", 1230); 
	//	map.put("Class", 1103);
		System.out.println(map);
	}
}
