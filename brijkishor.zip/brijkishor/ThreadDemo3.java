package brijkishor;

class MyThread4 extends Thread
{
	
}

public class ThreadDemo3 {
	public static void main(String[] args) {
		MyThread4 thread = new MyThread4(); 
		thread.start();
	}
}
