package brijkishor;

import java.io.FileReader;
import java.io.IOException;
import java.net.CookieHandler;
import java.util.Iterator;

public class FileReaderDemo {
	public static void main(String[] args) throws IOException {
		FileReader fileReader = new FileReader("cricket.txt"); 
		int i = fileReader.read(); 
		while (i!=-1) {
			System.out.print((char)i);
			i = fileReader.read(); 
		}
	}
}
